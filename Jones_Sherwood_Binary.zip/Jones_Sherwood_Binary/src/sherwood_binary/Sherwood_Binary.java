/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sherwood_binary;

import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;
/**
 * Class Name: Sherwood_Binary
 * Class Author: Angelica Jones
 * ‘*** Purpose of the class: print out the array, show the user, 
 * allow the user to pick the number they want to search for and display the results of each algorithm
 * Date 4/22/18
 * List of changes with dates. 
 * @author aj035
 */
public class Sherwood_Binary {

    /**
     * @param args the command line arguments
     */
    //giving full credit to java2s.com for using an array filled with random numbers
//    private static int[] theArray;

    //giving full credit to javatpoint.com to implementa binary search
    /*
    ‘***  Method Name: binarySearch
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method: implement the binary search
‘*** Method Inputs: none 
‘*** parameters: integer arrays, first value, last value, key value
‘*** Return value: none
‘******************************************************
‘*** Date 4/23/18
    */
    public static void binarySearch(int binaryArray[], int firstValue, int lastValue, int key)
    {
        //first we declare the variable for the middle value
        //this is the main identifier of the binary search algorithm
        int middle = (firstValue + lastValue)/2;
        
        //count how many times the middle is used
        int binaryCount = 0;
            //omg idk why my code is orange
            //while loop is used instead of for loop because you don't know how many times the data will be cut in half
            while( firstValue <= lastValue )
            {
                //the middle of the array is less than the value look for
                if ( binaryArray[middle] < key )
                {
                    //move over to the side
                    firstValue = middle + 1;   
                    binaryCount++;
                }
                //here the data value is found
                else if (binaryArray[middle] == key)
                {
                   System.out.println("Element is found at index: " + middle);
                   binaryCount++;
                  System.out.println("Binary search ran " + binaryCount + " times");
                   //count the iterations

                   //break out of the while loop if the value is found
            break;
            
            }
                // middle is greater than the value looked for
                else
                {
                    lastValue = middle - 1;
                }
                //keeps cuting data in half
                middle = (firstValue + lastValue)/2;
                binaryCount++;
               
                
            }
        
            //count the iterations
        
        //this shows if the value is never found
        if (firstValue > lastValue)
        {
            System.out.println("Element is not found!");
        }
    }
    
    
    //giving full credit to stackoverflow.com to implement a sherwood algorithm
    /*
    ‘***  Method Name: sherwoodAlgorithm
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method: implement the binary search
‘*** Method Inputs: none 
‘*** parameters: integer arrays, first value, last value, key value
‘*** Return value: none
‘******************************************************
‘*** Date 4/23/18
    */
    public static void sherwoodAlgorithm(int sherArray[], int firstValue2, int lastValue2, int key2)
    {
        //create a random object
        Random rand = new Random();
        //this is the main identifier for a sherwood algorithm
        //giving full credit to Dr. Woodcock for sherwood algorithm
        int middle = firstValue2 + rand.nextInt(lastValue2 - firstValue2 + 1);
        int sherwoodCount = 0;
        while( firstValue2 <= lastValue2 )
        {
            //the middle of the array is less than the value look for
            if ( sherArray[middle] < key2 )
            {
                //move over to the half side with the value
                firstValue2 = middle + 1;
                sherwoodCount++;
            }
            //here the data value is found
            else if ( sherArray[middle] == key2 )
            {
               System.out.println("Element is found at index: " + middle);
               //break out of the while loop if the value is found
                sherwoodCount++;
                System.out.println("Sherwood Algorithm ran " + sherwoodCount + " times");
                 //count the iterations
            break;
            }
            else
            {
                lastValue2 = middle - 1;
            }
            middle = (firstValue2 + lastValue2)/2;
            sherwoodCount++;
            //giving full credit to stackoverflow.com to place ocmparisons in the correct spot
        }
        if (firstValue2 > lastValue2)
        {
            System.out.println("Element is not found!");
        }   
    }
    
    
   //giving full credit to javatpoint.com to implement an array within a search
    /*
    ‘***  Method Name: main
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method: adds the array values to the binary search/sherwood algorithm
‘*** Method Inputs: none 
‘*** parameters:
‘*** Return value: none
‘******************************************************
‘*** Date 4/23/18
    */  
    public static void main(String[] args) 
    {
        //this will calculate the runtime in miliseconds
        long start = System.currentTimeMillis();
    
        //this is where the binary search will happen
        //here is the array with the numbers(here are 100 numbers)
        int arrBin[] = 
        {10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 
        20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 
        30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 
        40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 
        50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 
        60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 
        70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 
        80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 
        90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 
        100};
        //this is the positon of the number i want to find
        int keyBin = 56;
        int lastBin=arrBin.length-1;
        //call the method with the correct parameters
        binarySearch(arrBin,0,lastBin,keyBin);
        System.out.println(" \n");
        
        //got the run time in miliseconds from youtuber Telusko Learnigs
        long end = System.currentTimeMillis();
        long finalTime = end -start;
        //System.out.println(finalTime);
        //this gets the average time from start to finish
        //print out the time in nanoseconds
        System.out.println("Binary took " + finalTime + " nanoseconds");
        System.out.println(" \n");

        
                
        //this is where the sherwood algorithm will happen
        //this will calculate the runtime in miliseconds
        long start1 = System.currentTimeMillis();
        int arrSher[] = 
        {10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 
        20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 
        30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 
        40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 
        50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 
        60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 
        70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 
        80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 
        90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 
        100};
        
        //position that i want to find the number
	int keySher = 56;
        int lastSher=arrSher.length-1;
        //still the same as the binary search
	sherwoodAlgorithm(arrSher,0,lastSher,keySher);
        System.out.println(" \n");
        
        //got the run time in miliseconds from youtuber Telusko Learnigs
        long end1 = System.currentTimeMillis();
        long finalTime1 = end1 -start1;
        //System.out.println(finalTime1);
        //this gets the average time from start to finish
        //print out the time in nanoseconds
        System.out.println("Sherwood took " + finalTime1 + " nanoseconds");
        System.out.println(" \n");
    }
}
