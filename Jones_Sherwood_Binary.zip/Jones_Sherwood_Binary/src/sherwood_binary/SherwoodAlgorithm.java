/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sherwood_binary;

import java.util.Random;

/**
 * Class Name: SherwoodAlgorithm
 * Class Author: Angelica Jones
 * ‘*** Purpose of the class: to create a sherwood algorithm search
 * Date 4/22/18
 * List of changes with dates. 
 * @author aj035
 */

//public class SherwoodAlgorithm 
//{
//   public int runBinary(int theArray [], int location)
//    {
//        Random rand = new Random();
//        //this will calculate the runtime in miliseconds
//        long start = System.currentTimeMillis();
//        long finish = System.currentTimeMillis();
//        int begin = 0;
//        int end = theArray.length - 1;
//        //while loop is used because programmer doesn't know how many times data needs to be split to find the value
//        while (begin <= end)
//        {
//            //this algorithm splits the data in half repeatedly
//            int middle = (begin + end) / 2;
//            if (location == theArray[middle]) {
//                return middle;
//            }
//            if (location < theArray[middle]) {
//                end = middle - 1;
//            } 
//            else 
//            {
//                begin = middle + 1;
//            }
//        }
//        
//            //got the run time in miliseconds from youtuber Telusko Learnigs
//       
//        long finalTime = finish - start;
//        System.out.println(finalTime);
//        //this gets the average time from start to finish
//        //print out the time in nanoseconds
//        System.out.println(finalTime + " nanoseconds");
//        System.out.println(" \n");
//        return -1;
//        
//     
//        
//    } 
//}
