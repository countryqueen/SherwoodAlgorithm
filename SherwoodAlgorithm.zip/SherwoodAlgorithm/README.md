# SherwoodAlgorithm
For this assignment, I want you to take a Binary Search program and convert it to a Sherwood algorithm program.   In Binary search you always find the middle of the range, recursively choosing the side that has the value you are looking for.  In Sherwood you randomly select any point in the range rather than the middle to divide and conquer.
